package shop.online.domain;

public enum DeliveryStatus {
    READY,
    COMP
}
